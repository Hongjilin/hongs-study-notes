![image-20200822204428983](C:%5CUsers%5C%E6%B4%AA%5CAppData%5CRoaming%5CTypora%5Ctypora-user-images%5Cimage-20200822204428983.png)









新vue文件

yarn add element-ui









![image-20200824190520609](../../../AppData/Roaming/Typora/typora-user-images/image-20200824190520609.png)



















要求



管理员-学生管理
		管理员-通知管理

​	导入ex文件



学生-我的通知
		学生-健康填报
		学生-在线群聊，单聊
		学生-请假申请
		学生-个人信息

教师-通知管理
		教师-请假管理
		教师-个人信息



教师与学生可以在线聊天  群聊与单聊
var express = require("express");
var expressStaticGzip = require("express-static-gzip");
var app = express();

app.use(
  "/",
  expressStaticGzip("/my/rootFolder/", {
    enableBrotli: true,
    customCompressions: [
      {
        encodingName: "deflate",
        fileExtension: "zz",
      },
    ],
    orderPreference: ["br"],
  })
);
